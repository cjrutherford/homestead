export const slides = [
  { slug: 'app-overview', title: 'Your inventory.<br>In clear view.', sub: 'Stock, suppliers, and sales together.', label: 'Inventory, at a glance' },
  { slug: 'stock-by-location', title: 'Put every item<br>in place.', sub: 'Find it. Move it. Keep shelves stocked.', label: 'Across every location' },
  { slug: 'smart-reordering', title: 'Reorder before<br>shelves run empty.', sub: 'Turn recent demand into your next order.', label: 'Know what to buy next' },
  { slug: 'scan-and-take-out', title: 'Scan more.<br>Finish in one.', sub: 'One basket. One stock update.', label: 'Built for busy days' },
  { slug: 'sales-and-profit', title: 'See what earns<br>its keep.', sub: 'Follow your sales and real gross profit.', label: 'Make the numbers useful' },
];

export function composition({ index, width, height, ui }) {
  const slide = slides[index];
  const mobile = height > width;
  const tablet = width === 1024;
  const title = slide.title.replace('<br>', (tablet || (index === 0 && !mobile)) ? ' ' : '<br>');
  const image = (name, cls = '') => `<img class="ui ${cls}" src="/store/source/ui/${name}.png" width="${ui[name].width * 4}" height="${ui[name].height * 4}" alt="${name.replaceAll('-', ' ')}">`;
  let showcase;
  if (index === 0) {
    showcase = `<div class="whole-app">${image(mobile ? 'overview-mobile' : 'overview-desktop')}</div>${!mobile && !tablet ? image('overview-value', 'overview-value') : ''}`;
  } else if (index === 1) {
    showcase = mobile
      ? `<div class="product-label">Laptop Stand</div>${image('location-card', 'complete-card')}`
      : `<div class="product-label">Laptop Stand</div><div class="fragment">${image('location-warehouse')}</div><div class="fragment">${image('location-storefront')}</div>`;
  } else if (index === 2) {
    showcase = mobile
      ? image('reorder-card', 'complete-card')
      : `${tablet ? '' : `<div class="supplier-head">${image('reorder-heading')}</div>`}<div class="fragment">${image('reorder-line')}</div>${image('reorder-button', 'action-img')}`;
  } else if (index === 3) {
    showcase = `${tablet ? '' : image('scan-button', 'scan-img')}<div class="fragment">${image('takeout-wireless')}</div>${!tablet ? `<div class="fragment">${image('takeout-dotted')}</div>` : ''}${image('takeout-button', 'action-img')}`;
  } else {
    showcase = mobile
      ? `${image('sales-grid', 'sales-grid')}${image('sales-chart', 'complete-card chart-card')}`
      : `<div class="sales-pair">${image('sales-revenue')}${image('sales-gross-profit')}</div>`;
  }
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${slide.slug}</title><style>
  *{box-sizing:border-box}html,body{margin:0;width:${width}px;height:${height}px;overflow:hidden}
  body{font-family:system-ui,-apple-system,"Segoe UI",sans-serif;-webkit-font-smoothing:antialiased;background:#fff6e9;color:#241302}
  .canvas{position:relative;width:100%;height:100%;overflow:hidden;isolation:isolate}
  .canvas:before{content:"";position:absolute;width:1240px;height:1240px;background:#ff8f15;border-radius:50%;right:-530px;bottom:-440px;z-index:-2}
  .canvas:after{content:"";position:absolute;width:980px;height:980px;border:2px solid rgba(168,88,0,.19);border-radius:50%;right:-255px;top:-600px;z-index:-1}
  .brand{position:absolute;left:88px;top:56px;display:flex;align-items:center;gap:18px;font-size:36px;font-weight:720;letter-spacing:-1px;line-height:1}
  .brand img{width:60px;height:60px;border-radius:16px;box-shadow:0 7px 18px #a8580015}
  .page-number{position:absolute;right:90px;top:68px;display:flex;align-items:center;gap:15px;font-size:30px;font-weight:650;letter-spacing:1px}
  .page-number span{height:2px;width:44px;background:currentColor;opacity:.4}
  .copy{position:absolute;left:88px;top:241px;width:780px}
  h1{font-size:112px;line-height:1.015;letter-spacing:-4.8px;font-weight:780;margin:0}
  .sub{font-size:36px;line-height:1.4;letter-spacing:-.7px;margin:38px 0 0;max-width:750px;color:#65452b}
  .eyebrow{position:absolute;left:90px;bottom:90px;display:flex;align-items:center;gap:18px;font-size:32px;font-weight:600;letter-spacing:-.5px}
  .eyebrow:before{content:"";height:12px;width:12px;background:#a85800;border-radius:50%}
  .showcase{position:absolute;left:980px;right:88px;top:210px;bottom:88px;display:flex;flex-direction:column;justify-content:center;align-items:stretch;gap:28px}
  .ui{display:block;width:100%;height:auto;flex:none}
  .fragment{border-radius:24px;background:#fff;overflow:hidden;box-shadow:0 22px 44px #65360a15,0 1px 2px #65360a12;outline:1px solid #e9dfd0}
  .complete-card{border-radius:30px;box-shadow:0 25px 65px #65360a20}
  .product-label{font-size:38px;font-weight:650;letter-spacing:-1px;padding:0 6px 6px}
  .action-img{width:65%;align-self:flex-end;border-radius:22px;box-shadow:0 12px 22px #65360a14}
  .supplier-head{background:white;padding:30px;border-radius:26px}
  .scan-img{width:31%;align-self:flex-start;border-radius:18px}
  .sales-pair{display:flex;flex-direction:column;gap:30px;width:79%;align-self:center}
  .sales-pair .ui{border-radius:32px;box-shadow:0 22px 48px #65360a18}
  .whole-app{border:10px solid #fff;border-radius:25px;box-shadow:0 35px 90px #713f1830;overflow:hidden;background:#fff}
  .slide-0{background:#ff8f15}
  .slide-0:before{background:#ffb860;width:1460px;height:1460px;right:-450px;bottom:-720px}
  .slide-0:after{border-color:#24130220;width:1400px;height:1400px;right:-600px;top:-870px}
  .slide-0 .copy{top:145px;width:1744px;left:88px}
  .slide-0 h1{font-size:91px;letter-spacing:-4.5px;line-height:1.02}
  .slide-0 h1 br{display:none}.slide-0 h1 br:after{content:" "}
  .slide-0 .sub{margin:22px 0 0;font-size:35px;color:#482700}
  .slide-0 .showcase{left:503px;right:90px;top:326px;bottom:43px;justify-content:flex-start}
  .slide-0 .whole-app{position:absolute;width:1090px;right:0;bottom:0}
  .overview-value{position:absolute;width:530px;left:-415px;top:166px;border-radius:32px;box-shadow:0 22px 55px #713f1825}
  .slide-0 .eyebrow{left:90px;bottom:90px;width:355px;line-height:1.25;align-items:flex-start}
  .slide-0 .eyebrow:before{flex-shrink:0;margin-top:13px;background:#241302}
  .slide-1 .copy{width:760px}.slide-1 .showcase{gap:34px}
  .slide-2 h1{font-size:101px}.slide-2 .showcase{gap:24px;left:975px}.slide-2 .action-img{width:100%}
  .slide-3{background:#241b15;color:#fff7ed}
  .slide-3:before{background:#ff8f15;right:-740px;bottom:-790px}
  .slide-3:after{border-color:#ffffff14}
  .slide-3 .sub{color:#e6c4a0}.slide-3 .eyebrow{color:#ffb45f}.slide-3 .eyebrow:before{background:#ff8f15}
  .slide-3 .fragment{outline:0}.slide-3 .showcase{gap:24px;top:170px;bottom:65px}
  .slide-4 .showcase{top:170px;bottom:82px}.slide-4 .sub{max-width:695px}

  ${tablet ? `
  .brand{left:48px;top:35px;font-size:29px;gap:12px}.brand img{width:44px;height:44px;border-radius:12px}
  .page-number{right:49px;top:45px;font-size:25px;gap:10px}.page-number span{width:30px}
  .copy,.slide-0 .copy,.slide-1 .copy{left:48px;top:111px;width:940px}
  h1,.slide-2 h1,.slide-0 h1{font-size:58px;line-height:1.04;letter-spacing:-2.2px}
  h1 br{display:none}h1 br:after{content:" "}
  .sub,.slide-0 .sub{font-size:28px;line-height:1.2;margin:18px 0 0;letter-spacing:-.5px;max-width:930px}
  .eyebrow{display:none}
  .showcase,.slide-2 .showcase,.slide-4 .showcase{left:110px;right:110px;top:267px;bottom:44px;gap:20px}
  .product-label{font-size:29px;padding:0 4px}.fragment{border-radius:20px}
  .action-img{width:51%;border-radius:16px;align-self:flex-end}
  .slide-0 .copy{top:106px}.slide-0 h1{font-size:55px}
  .slide-0 .showcase{left:120px;right:120px;top:226px;bottom:29px}
  .slide-0 .whole-app{position:static;width:100%;border-width:7px;border-radius:20px}
  .slide-0 .sub{font-size:27px;margin-top:15px}
  .slide-0:before{width:1100px;height:1100px;right:-400px;bottom:-700px}
  .slide-1 .showcase{gap:20px;left:90px;right:90px}
  .slide-2 .copy{width:850px}.slide-2 h1{font-size:57px}.slide-2 .showcase{top:271px;left:120px;right:120px}
  .slide-3 .showcase{left:112px;right:112px;top:284px;bottom:62px;gap:24px}
  .slide-4 .showcase{left:70px;right:70px;top:310px;bottom:95px}
  .sales-pair{flex-direction:row;width:100%;gap:24px}.sales-pair .ui{width:calc(50% - 12px);height:auto;align-self:start;border-radius:26px}
  ` : ''}
  ${mobile ? `
  .canvas:before{width:1400px;height:1400px;right:-500px;bottom:-650px}.canvas:after{width:1200px;height:1200px;right:-590px;top:-490px}
  .brand{left:76px;top:88px;font-size:44px;gap:19px}.brand img{width:76px;height:76px;border-radius:21px}
  .page-number{right:78px;top:108px;font-size:32px}
  .copy,.slide-0 .copy,.slide-1 .copy{left:76px;top:269px;width:960px}
  h1,.slide-0 h1{font-size:119px;line-height:1.06;letter-spacing:-5px}
  .slide-0 h1 br{display:block}.slide-0 h1 br:after{content:none}
  .sub,.slide-0 .sub{font-size:41px;line-height:1.4;letter-spacing:-.8px;margin-top:36px;max-width:900px}
  .showcase,.slide-2 .showcase,.slide-4 .showcase{left:76px;right:76px;top:815px;bottom:280px;gap:34px;justify-content:center}
  .eyebrow,.slide-0 .eyebrow{display:flex;left:78px;bottom:105px;width:900px;font-size:38px;gap:20px;align-items:center}
  .eyebrow:before,.slide-0 .eyebrow:before{width:14px;height:14px;margin:0}
  .slide-0 .showcase{left:92px;right:92px;top:750px;bottom:214px}
  .slide-0 .whole-app{position:static;width:100%;border:10px solid white;border-radius:32px;flex-shrink:0}
  .slide-0 .sub{max-width:900px}.slide-0:before{right:-510px;bottom:-550px}
  .slide-1 .showcase{top:788px;bottom:272px;gap:36px}.product-label{font-size:44px;padding-left:5px}
  .complete-card{border-radius:34px}
  .slide-2 h1{font-size:108px;line-height:1.075}.slide-2 .showcase{top:825px;bottom:224px}
  .slide-2 .sub{max-width:930px;font-size:40px}
  .slide-3 .showcase{top:790px;bottom:262px;gap:28px}.scan-img{width:32%}.action-img{width:67%;border-radius:22px}
  .slide-4 .showcase{top:820px;bottom:320px;gap:38px}.sales-grid{border-radius:30px}.chart-card{border-radius:30px}
  ` : ''}
  </style></head><body><main class="canvas slide-${index}"><div class="brand"><img src="/icon-192.png" alt="">Inventory</div><div class="page-number">0${index + 1}<span></span>05</div><div class="copy"><h1>${title}</h1><p class="sub">${slide.sub}</p></div><div class="showcase">${showcase}</div><div class="eyebrow">${slide.label}</div></main></body></html>`;
}
